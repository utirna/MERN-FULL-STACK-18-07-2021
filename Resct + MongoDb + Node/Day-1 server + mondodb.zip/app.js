const express = require("express");
const createError = require("http-errors");
const logger = require("morgan");
const cors = require("cors");
const app = express();
const mongoose = require("mongoose");
const router = require("./app/router/index");
const ApiRouter = require("./app/router/ApiRouter");

app.use(cors());

app.use(logger("dev"));

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use("/", router);
app.use("/api", ApiRouter);

//create 404 error
app.use(function (req, res, next) {
  next(createError(404));
});

//error handler
app.use(function (error, req, res, next) {
  res.status(error.status || 500);
  res.send({ status: false, message: error.message });
});

let dbUrl = "mongodb://127.0.0.1:27017/student_db";

console.log("connecting to db...");
mongoose
  .connect(dbUrl)
  .then(() => {
    console.log("db connected !!!");
    app.listen(3001, function () {
      console.log("express server is running on 3001");
    });
  })
  .catch((error) => {
    console.error(error);
    process.exit(1); // crash
  });

/*
1 create connection !!! done !!!
2 create model
2 use model
*/
