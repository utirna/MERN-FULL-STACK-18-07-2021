/*
import mongoose
create schema
create model

export model
*/
const mongoose = require("mongoose");

const StudentDetail = new mongoose.Schema({
  name: { type: String },
  course: { type: String },
}); // schema build ==> how your document will loos like

const StudentDetailsModel = mongoose.model("student_detail", StudentDetail);

module.exports = StudentDetailsModel;

//CRUD
