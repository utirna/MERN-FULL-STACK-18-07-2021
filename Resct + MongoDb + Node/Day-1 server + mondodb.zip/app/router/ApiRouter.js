const express = require("express");
const router = express.Router();
const StudentApiController = require("../controller/api/StudentApiController");

router.get("/", StudentApiController.home);

router.get("/student-list", StudentApiController.studentList);

module.exports = router;
