var StudentApi = {
  home: function (req, res) {
    res.send({ status: true });
  },
  studentList: function (req, res) {
    res.send({ status: true, data: "student-list" });
  },
};

module.exports = StudentApi;
