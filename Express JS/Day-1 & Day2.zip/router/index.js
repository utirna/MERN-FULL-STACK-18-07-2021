const express = require("express");
const router = express.Router();
const studentList = [
  {
    name: "Rahul",
    roll_no: 11,
  },
  {
    name: "Rohan",
    roll_no: 12,
  },
  {
    name: "Ajay",
    roll_no: 13,
  },
  {
    name: "Amar",
    roll_no: 14,
  },
  {
    name: "Santosh",
    roll_no: 15,
  },
];

/*get */
router.get("/", function (request, response) {
  response.send(`<h1 style='color:red'>hello node js home page</h1>`);
});

router.get("/api/get-student-list", function (req, res) {
  res.send({
    student: studentList,
    studentCount: studentList.length,
  });
});

router.get("/api/get-student-details/:roll_no", function (req, res) {
  let { roll_no } = req.params;
  let student = studentList.find(function (student) {
    return student.roll_no == roll_no;
  });

  if (student === undefined) {
    res.send({ status: false, msg: "student not found" });
  } else {
    res.send({ status: true, student: student });
  }
});

/* post */
router.post("/", function (req, res) {
  res.send("this is post data");
});

/* delete */
router.delete("/", function (req, res) {
  res.send("this is delete data");
});

module.exports = router; //es5
