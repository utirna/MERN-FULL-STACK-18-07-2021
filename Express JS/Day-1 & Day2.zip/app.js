const express = require("express");
const app = express();
const router = require("./router/index");

app.use("/", router);

app.listen(3001, function () {
  console.log("express server is running");
});
