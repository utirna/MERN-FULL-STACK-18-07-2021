const express = require("express");
const ApiRouter = express.Router();
const StudentApiController = require("../controller/ApiController/StudentApiController");
/* get */
ApiRouter.get("/", StudentApiController.apiHome);
ApiRouter.get("/student/list", StudentApiController.studentList);
ApiRouter.get(
  "/student/details/:id",
  StudentApiController.singleStudentDetails
);

/* delete */
ApiRouter.delete("/student/delete/:id", StudentApiController.studentDelete);

/* post */
ApiRouter.post("/student/add", StudentApiController.addStudent);

module.exports = ApiRouter;
