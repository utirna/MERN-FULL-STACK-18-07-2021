const express = require("express");
const router = express.Router();

/*get */
router.get("/", function (request, response) {
  response.send(`<h1 style='color:red'>hello node js home page</h1>`);
});

/* post */
router.post("/", function (req, res) {
  res.send("this is post data");
});

/* delete */
router.delete("/", function (req, res) {
  res.send("this is delete data");
});

module.exports = router; //es5
