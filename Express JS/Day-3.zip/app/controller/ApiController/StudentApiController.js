const studentList = [
  {
    name: "Rahul",
    id: 1,
    course: "React",
  },
  {
    name: "Rohan",
    id: 2,
    course: "Node JS",
  },
  {
    name: "Ajay",
    id: 3,
    course: "Full Stack",
  },
  {
    name: "Amar",
    id: 4,
    course: "JAVA",
  },
  {
    name: "Santosh",
    id: 5,
    course: "React",
  },
];

const StudentApiController = {
  apiHome: function (req, res) {
    res.send("its working");
  },
  studentList: function (req, res) {
    res.send({
      student: studentList,
      studentCount: studentList.length,
    });
  },
  singleStudentDetails: function (req, res) {
    let { id } = req.params;
    let student = studentList.find(function (student) {
      return student.id == id;
    });

    if (student === undefined) {
      res.send({ status: false, message: "student not found" });
    } else {
      res.send({ status: true, student: student });
    }
  },
  studentDelete: function (req, res) {
    let { id } = req.params;
    let index = studentList.findIndex(function (student) {
      return student.id === Number(id);
    });
    if (index === -1) {
      res.send({ status: false, message: "student not found" });
    } else {
      studentList.splice(index, 1);
      res.send({ status: true, message: "student deleted successfully" });
    }
  },
  addStudent: function (req, res) {
    let data = req.body;

    let length = studentList.length;
    if (length === 0) {
      data["id"] = 1;
    } else {
      data["id"] = studentList[length - 1].id + 1;
    }

    studentList.push({ ...data });
    res.send({ status: true, message: "student added successfully" });
  },
};

module.exports = StudentApiController;
