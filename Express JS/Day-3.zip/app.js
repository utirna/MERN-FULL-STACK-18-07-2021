const express = require("express");
const app = express();
const router = require("./app/router/index");
const ApiRouter = require("./app/router/ApiRouter");

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use("/", router);
app.use("/api", ApiRouter);

app.listen(3001, function () {
  console.log("express server is running on 3001");
});
