import React from "react";
import { useNavigate } from "react-router-dom";

function ViewStudentList(props) {
  let { studentList, removeStudent } = props;
  let navigate = useNavigate();
  return (
    <>
      <section className="row justify-content-center">
        <p className="text-center h5 text-success">Student List</p>
        <section className="col-12 col-md-10 col-lg-10  card m-3">
          {studentList.length == 0 ? (
            <p className="text-center"> No Student Found</p>
          ) : (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th width="10%">Sr No</th>
                  <th width="30%">Student Name</th>
                  <th width="15%">Mobile</th>
                  <th width="20%">Course</th>
                  <th width="10%">Fee Status</th>
                  <th width="15%">Action</th>
                </tr>
              </thead>
              <tbody>
                {studentList.map((student, index) => {
                  let pay_status =
                    student.advance_payment === "1" ? "Paid" : "UnPaid";
                  return (
                    <tr key={index}>
                      <td>{index + 1}</td>
                      <td>{student.s_name}</td>
                      <td>{student.mobile}</td>
                      <td>{student.course}</td>
                      <td>{pay_status}</td>
                      <td>
                        <button
                          className="btn btn-danger m-1 btn-sm"
                          onClick={() => removeStudent(index)}
                        >
                          <span className="fa fa-trash"></span>
                        </button>
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => navigate("/edit-student/" + index)}
                        >
                          <span className="fa fa-edit"></span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </section>
      </section>
    </>
  );
}

export default ViewStudentList;
