import { Field, Form, Formik } from "formik";
import React from "react";
import { toast } from "react-toastify";

function CreateNewStudent(props) {
  let { studentList, setStudentList } = props;

  let initialValues = {
    s_name: "",
    mobile: "",
    course: "",
    advance_payment: "",
  };

  let onSubmit = (values, onSubmitProps) => {
    let _studentList = [...studentList];
    _studentList.push(values);
    setStudentList(_studentList);
    onSubmitProps.resetForm();
    toast.success("Student Save Successfully.");
  };
  return (
    <div className="row justify-content-center">
      <section className="col-8 col-lg-4">
        <p className="text-center h5 text-success">New Student Registration</p>
        <section className="card p-3 mt-4">
          <Formik initialValues={initialValues} onSubmit={onSubmit}>
            <Form className="d-flex flex-column">
              <div className="mb-2">
                <label htmlFor="" className="form-label">
                  Student Name
                </label>
                <Field
                  type="text"
                  className="form-control"
                  placeholder="Enter Name"
                  name="s_name"
                  autoComplete="off"
                />
              </div>

              <div className="mb-2">
                <label htmlFor="" className="form-label">
                  Mobile
                </label>
                <Field
                  type="text"
                  className="form-control"
                  placeholder="Enter Mobile No"
                  name="mobile"
                  autoComplete="off"
                />
              </div>

              <div className="mb-2">
                <label htmlFor="" className="form-label">
                  Course
                </label>
                <Field as="select" className="form-select" name="course">
                  <option value="">--- Select ---</option>
                  <option value="React">React</option>
                  <option value="Node JS">Node JS</option>
                  <option value="FontEnd Development">
                    FontEnd Development
                  </option>
                  <option value="BackEnd Development">
                    BackEnd Development
                  </option>
                </Field>
              </div>

              <div className="mb-2">
                <label htmlFor="">Advance Fee</label>
                <div className="form-check">
                  <Field
                    type="radio"
                    className="form-check-input"
                    value="1"
                    name="advance_payment"
                    id="advance_payment_1"
                  />
                  <label
                    htmlFor="advance_payment_1"
                    className="form-check-label text-success"
                  >
                    Paid
                  </label>
                </div>
                <div className="form-check">
                  <Field
                    type="radio"
                    className="form-check-input"
                    value="0"
                    name="advance_payment"
                    id="advance_payment_0"
                  />
                  <label
                    htmlFor="advance_payment_0"
                    className="form-check-label text-danger"
                  >
                    Unpaid
                  </label>
                </div>
              </div>
              <button className="btn btn-primary pl-3 pr-4" type="submit">
                <span className="fa fa-save "></span>&nbsp;&nbsp; Save
              </button>
            </Form>
          </Formik>
        </section>
      </section>
    </div>
  );
}

export default CreateNewStudent;
