import React from "react";
import { Link } from "react-router-dom";

function NavBar(props) {
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="navbar-nav">
          <Link className="nav-link active" aria-current="page" to="/">
            Dashboard
          </Link>
          <Link className="nav-link" to="/new-student">
            Add Student
          </Link>
          <Link className="nav-link" to="/view-students">
            Student List
          </Link>
        </div>
      </nav>
    </>
  );
}

export default NavBar;
