import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import CreateNewStudent from "./components/CreateNewStudent";
import Dashboard from "./components/Dashboard";
import NavBar from "./components/NavBar";
import EditStudent from "./components/EditStudent";
import ViewStudentList from "./components/ViewStudentList";
import { Route, Routes } from "react-router-dom";
import PageNotFound from "./components/PageNotFound";

function App(props) {
  let [studentList, setStudentList] = useState([
    {
      s_name: "Ajay",
      mobile: "789654789",
      course: "Node JS",
      advance_payment: "1",
    },
    {
      s_name: "Ruchika",
      mobile: "7896547854",
      course: "FontEnd Development",
      advance_payment: "1",
    },
    {
      s_name: "Archana",
      mobile: "78547856985",
      course: "FontEnd Development",
      advance_payment: "1",
    },
    {
      s_name: "Suraj",
      mobile: "6547896547",
      course: "Node JS",
      advance_payment: "0",
    },
  ]);

  let removeStudent = (index) => {
    let _studentList = [...studentList];

    _studentList.splice(index, 1);

    setStudentList(_studentList);

    toast.info("Student Removed Successfully.");
  };

  let updateStudentDetails = (index, values) => {
    let _studentList = [...studentList];
    _studentList[index] = { ...values };
    setStudentList(_studentList);
    toast.success("Student Updated Successfully.");
  };
  return (
    <>
      <main className="container-fluid">
        <ToastContainer />
        <NavBar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route
            path="/new-student"
            element={
              <CreateNewStudent
                studentList={studentList}
                setStudentList={setStudentList}
              />
            }
          />
          <Route
            path="/edit-student/:id"
            element={
              <EditStudent
                studentList={studentList}
                updateStudentDetails={updateStudentDetails}
              />
            }
          />
          <Route
            path="/view-students"
            element={
              <ViewStudentList
                studentList={studentList}
                removeStudent={removeStudent}
              />
            }
          />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </main>
    </>
  );
}

export default App;
