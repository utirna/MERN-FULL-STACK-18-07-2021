import React from "react";
import { Formik, useFormik } from "formik";
function StudentForm() {
  let initialValues = {
    s_name: "",
    roll_no: "",
    course: "",
  };

  let validate = (values) => {
    let error = {};
    if (values.s_name == "") {
      error["s_name"] = "Enter Student Name";
    }

    if (values.roll_no == "") {
      error["roll_no"] = "Enter Student Roll Number";
    }

    if (values.course == "") {
      error["course"] = "Select a Course";
    }

    return error;
  };

  let onSubmit = (values, onSubmitProps) => {
    console.log(values);
    onSubmitProps.resetForm();
  };

  let studentForm = useFormik({
    initialValues,
    validate,
    onSubmit,
  });

  return (
    <>
      <Formik>
        <form onSubmit={studentForm.handleSubmit}>
          <div>
            <label>Name*</label>
            <input
              type="text"
              name="s_name"
              value={studentForm.values.s_name}
              onBlur={studentForm.handleBlur}
              onChange={studentForm.handleChange}
              autoComplete="off"
            />
            {studentForm.touched.s_name ? (
              <span className="text-danger">{studentForm.errors.s_name}</span>
            ) : null}
          </div>

          <div>
            <label>Roll No*</label>
            <input
              type="text"
              name="roll_no"
              value={studentForm.values.roll_no}
              onBlur={studentForm.handleBlur}
              onChange={studentForm.handleChange}
              autoComplete="off"
            />
            {studentForm.touched.roll_no ? (
              <span className="text-danger">{studentForm.errors.roll_no}</span>
            ) : null}
          </div>

          <div>
            <label>Select A Course</label>
            <select
              name="course"
              value={studentForm.values.course}
              onChange={studentForm.handleChange}
              onBlur={studentForm.handleBlur}
            >
              <option value="">----Select----</option>
              <option value="js">Javascript</option>
              <option value="node_js">Node Js</option>
              <option value="react_js">React JS</option>
            </select>
            {studentForm.touched.course ? (
              <span className="text-danger">{studentForm.errors.course}</span>
            ) : null}
          </div>
          <button type="submit">Save</button>
        </form>
      </Formik>
    </>
  );
}

export default StudentForm;
