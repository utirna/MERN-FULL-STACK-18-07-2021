import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
function StudentForm() {
  let initialValues = {
    s_name: "",
    roll_no: "",
    course: "",
    address: "",
    gender: "",
    course_topic: ["html", "js"],
  };

  let validationSchema = Yup.object().shape({
    s_name: Yup.string()
      .min(3, "UserName must be grater the 3 characters")
      .max(7, "UserName must be less the 7 characters")
      .required("Enter User Name"),
    roll_no: Yup.number()
      .max(1000, "Roll Number Out Of Range (Max 1000)")
      .required("Enter Roll No"),
  });

  let onSubmit = (values, onSubmitProps) => {
    console.log(values);
    // onSubmitProps.resetForm();
  };

  return (
    <>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        <Form>
          <div>
            <label>Name*</label>
            <Field type="text" name="s_name" autoComplete="off" />
            <ErrorMessage
              name="s_name"
              className="text-danger"
              component="span"
            />
          </div>

          <div>
            <label>Roll No*</label>
            <Field type="number" name="roll_no" autoComplete="off" />
            <ErrorMessage
              name="roll_no"
              className="text-danger"
              component="span"
            />
          </div>

          <div>
            <label>Select A Course</label>
            <Field as="select" name="course">
              <option value="">----Select----</option>
              <option value="js">Javascript</option>
              <option value="node_js">Node Js</option>
              <option value="react_js">React JS</option>
            </Field>
            <ErrorMessage
              name="course"
              className="text-danger"
              component="span"
            />
          </div>
          <div>
            <label>Address</label>
            <Field as="textarea" name="address"></Field>
          </div>
          <div>
            <label>GENDER</label>
            <div>
              <label htmlFor="">Male</label>
              <Field type="radio" name="gender" value="Male" />

              <label htmlFor="">Female</label>
              <Field type="radio" name="gender" value="Female" />

              <label htmlFor="">Other</label>
              <Field type="radio" name="gender" value="Other" />
            </div>
          </div>

          <div>
            <label>COURSE Topic</label>
            <div>
              <label htmlFor="">HTML</label>
              <Field
                type="checkbox"
                name="course_topic"
                value="html"
                disabled
              />

              <label htmlFor="">JS</label>
              <Field type="checkbox" name="course_topic" value="js" />

              <label htmlFor="">React</label>
              <Field type="checkbox" name="course_topic" value="react" />
            </div>
          </div>
          <button type="submit">Save</button>
        </Form>
      </Formik>
    </>
  );
}

export default StudentForm;
