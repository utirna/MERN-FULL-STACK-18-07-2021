import React from "react";
import CreateNewStudent from "./components/CreateNewStudent";
import Dashboard from "./components/Dashboard";
import NavBar from "./components/NavBar";
import EditStudent from "./components/EditStudent";
import ViewStudentList from "./components/ViewStudentList";
import { Route, Routes } from "react-router-dom";
import PageNotFound from "./components/PageNotFound";

function App(props) {
  return (
    <>
      <main className="container-fluid">
        <NavBar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/new-student" element={<CreateNewStudent />} />
          <Route path="/edit-student" element={<EditStudent />} />
          <Route path="/view-students" element={<ViewStudentList />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </main>
    </>
  );
}

export default App;
