import React from "react";

function PageNotFound(props) {
  return <div>Page Not Found</div>;
}

export default PageNotFound;
