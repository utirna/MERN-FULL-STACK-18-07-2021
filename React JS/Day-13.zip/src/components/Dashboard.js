import React from "react";

function Dashboard(props) {
  return (
    <div className="row justify-content-center">
      <section className="col-6">
        <p className="text-center">Welcome to DashBoard</p>
      </section>
    </div>
  );
}

export default Dashboard;
