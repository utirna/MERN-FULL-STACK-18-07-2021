import React from "react";

function ViewStudentList(props) {
  return (
    <>
      <section className="row justify-content-center">
        <p className="text-center h5 text-success">Student List</p>
        <section className="col-10 card m-3">
          <table className="table table-striped">
            <thead>
              <tr>
                <th width="10%">Sr No</th>
                <th width="40%">Student Name</th>
                <th width="15%">Mobile</th>
                <th width="10%">Course</th>
                <th width="10%">Fee Status</th>
                <th width="15%">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Student Name</td>
                <td>Mobile</td>
                <td>Course</td>
                <td>Paid</td>
                <td>
                  <button className="btn btn-danger m-1 btn-sm">Delete</button>
                  <button className="btn btn-primary btn-sm">Edit</button>
                </td>
              </tr>
              <tr>
                <td>1</td>
                <td>Student Name</td>
                <td>Mobile</td>
                <td>Course</td>
                <td>Paid</td>
                <td>
                  <button className="btn btn-danger m-1 btn-sm">Delete</button>
                  <button className="btn btn-primary btn-sm">Edit</button>
                </td>
              </tr>
              <tr>
                <td>1</td>
                <td>Student Name</td>
                <td>Mobile</td>
                <td>Course</td>
                <td>Paid</td>
                <td>
                  <button className="btn btn-danger m-1 btn-sm">Delete</button>
                  <button className="btn btn-primary btn-sm">Edit</button>
                </td>
              </tr>
            </tbody>
          </table>
        </section>
      </section>
    </>
  );
}

export default ViewStudentList;
