import React from "react";
import { Field, Form, Formik } from "formik";

function EditStudent(props) {
  return (
    <div className="row justify-content-center">
      <section className="col-8">
        <p className="text-center h5 text-success">Edit Student</p>
        <section className="card p-3 mt-4">
          <Formik>
            <Form className="d-flex flex-column">
              <div className="mb-2">
                <label htmlFor="" className="form-label">
                  Student Name
                </label>
                <Field
                  type="text"
                  className="form-control"
                  placeholder="Enter Name"
                />
              </div>

              <div className="mb-2">
                <label htmlFor="" className="form-label">
                  Mobile
                </label>
                <Field
                  type="text"
                  className="form-control"
                  placeholder="Enter Mobile No"
                />
              </div>

              <div className="mb-2">
                <label htmlFor="" className="form-label">
                  Course
                </label>
                <Field as="select" className="form-select">
                  <option value="">--- Select ---</option>
                  <option value="React">React</option>
                  <option value="Node JS">Node JS</option>
                  <option value="FontEnd Development">
                    FontEnd Development
                  </option>
                  <option value="BackEnd Development">
                    BackEnd Development
                  </option>
                </Field>
              </div>

              <div className="mb-2">
                <label htmlFor="">Advance Fee</label>
                <div className="form-check">
                  <Field type="radio" className="form-check-input" />
                  <label htmlFor="" className="form-check-label text-success">
                    Paid
                  </label>
                </div>
                <div className="form-check">
                  <Field type="radio" className="form-check-input" />
                  <label htmlFor="" className="form-check-label text-danger">
                    Unpaid
                  </label>
                </div>
              </div>
              <button className="btn btn-success pl-3 pr-4">Update</button>
            </Form>
          </Formik>
        </section>
      </section>
    </div>
  );
}

export default EditStudent;
