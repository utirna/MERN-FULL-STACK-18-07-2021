import React from "react";
function TopNavigation() {
  return (
    <>
      <nav className="nav-bar">
        <ul className="menu">
          <li>Dashboard</li>
          <li>New Student</li>
          <li>Student List</li>
        </ul>
      </nav>
    </>
  );
}

export default TopNavigation;
