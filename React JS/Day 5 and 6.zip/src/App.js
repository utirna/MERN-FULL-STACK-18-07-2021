import React, { useState, useEffect, useContext } from "react";
import AttendanceMarker from "./components/AttendanceMarker";
import StudentTable from "./components/StudentTable";

let studentsList = [
  {
    name: "Hritik",
    roll_no: 1,
    isPresent: true,
  },
  {
    name: "Ajay",
    roll_no: 2,
    isPresent: false,
  },
  {
    name: "Pallavi",
    roll_no: 3,
    isPresent: false,
  },
  {
    name: "Ruchika",
    roll_no: 4,
    isPresent: true,
  },
];

function App() {
  // states
  let [students, setStudents] = useState(studentsList);
  let [index, setIndex] = useState(-1);
  let [lastAttStatus, setLastAttStatus] = useState(false);

  // functions
  let deleteStudent = (index) => {
    let _newStudents = [...students];
    _newStudents.splice(index, 1);
    setStudents(_newStudents);
  };

  let markAttendance = (event) => {
    setIndex(Number(event.target.value));
  };

  let setAttendance = () => {
    if (index === -1) return false;

    let _students = [...students];
    _students[index].isPresent = !_students[index].isPresent;

    setLastAttStatus(_students[index].isPresent);
    setStudents(_students);
  };

  // useEffect

  useEffect(() => {
    if (index === -1) return false;

    let _student = { ...students[index] }; /* immute */
    setLastAttStatus(_student.isPresent);
  }, [index]);

  //return
  return (
    <>
      <AttendanceMarker
        markAttendance={markAttendance}
        students={students}
        lastAttStatus={lastAttStatus}
        setAttendance={setAttendance}
      />
      <StudentTable students={students} deleteStudent={deleteStudent} />
    </>
  );
}

export default App;
