import { Field, Form, Formik } from "formik";
import React from "react";

function Home({ saveStudent }) {
  let initialValues = {
    name: "",
    class: "",
  };
  let onSubmit = (values) => {
    saveStudent({ ...values });
  };
  return (
    <Formik initialValues={initialValues} onSubmit={onSubmit}>
      <Form>
        <div>
          <label htmlFor="">Student Name</label>
          <Field type="text" name="name" autoComplete="off" />
        </div>
        <div>
          <label htmlFor="">Class</label>
          <Field as="select" name="class">
            <option value="">--Section--</option>
            <option value="react">React</option>
            <option value="js">JS</option>
            <option value="node">Node</option>
            <option value="mongo_db">MongoDB</option>
          </Field>
        </div>
        <button type="submit">Save Student</button>
      </Form>
    </Formik>
  );
}

export default Home;
