import React from "react";

function Counter({ index, incCounter, counter }) {
  let updateCount = () => {
    incCounter(index);
  };
  return (
    <>
      <h1>{counter}</h1>
      <button onClick={updateCount} className="btn btn-success">
        Inc Count
      </button>
    </>
  );
}

export default Counter;
