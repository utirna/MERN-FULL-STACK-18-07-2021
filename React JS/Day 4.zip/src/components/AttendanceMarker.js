import React from "react";

function AttendanceMarker({
  markAttendance,
  students,
  lastAttStatus,
  setAttendance,
}) {
  return (
    <div className="att-mark">
      <select onChange={markAttendance}>
        <option value="-1">--- Select a Student ---</option>
        {students.map((student, index) => {
          return (
            <option key={index} value={index}>
              {student.name}
            </option>
          );
        })}
      </select>
      {lastAttStatus ? (
        <button className="btn-danger" onClick={setAttendance}>
          Mark As Absent
        </button>
      ) : (
        <button className="btn-success" onClick={setAttendance}>
          Mark As Present
        </button>
      )}
    </div>
  );
}

export default AttendanceMarker;
