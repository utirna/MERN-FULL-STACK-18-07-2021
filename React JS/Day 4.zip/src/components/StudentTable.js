import React from "react";
import TableRow from "./TableRow";
function StudentTable({ students, deleteStudent }) {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>Sr No</th>
          <th>Name</th>
          <th>Roll No</th>
          <th>Attendance</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {students.map((student, index) => {
          return (
            <TableRow
              key={index}
              student={student}
              index={index}
              deleteStudent={deleteStudent}
            />
          );
        })}
      </tbody>
    </table>
  );
}
export default StudentTable;
