import React from "react";

function TableRow({ student, index, deleteStudent }) {
  let pStatus = student.isPresent == true ? "Yes" : "No";
  return (
    <tr>
      <td>{index + 1}</td>
      <td>{student.name}</td>
      <td>{student.roll_no}</td>
      <td>{pStatus}</td>
      <td>
        <button className="btn btn-danger" onClick={() => deleteStudent(index)}>
          Delete
        </button>
      </td>
    </tr>
  );
}

export default TableRow;
