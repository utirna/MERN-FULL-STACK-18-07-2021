import React, { useState } from "react";
import Counter from "./components/Counter";

function App() {
  let [counter, setCounter] = useState([
    {
      count: 0,
    },
    {
      count: 0,
    },
    {
      count: 0,
    },
    {
      count: 0,
    },
    {
      count: 0,
    },
  ]);

  let incCounter = (index) => {
    let _newCounter = [...counter];
    _newCounter[index].count += +1;
    setCounter(_newCounter);
  };
  return (
    <>
      {counter.map(function (counter, index) {
        return (
          <Counter
            key={index}
            counter={counter.count}
            incCounter={incCounter}
            index={index}
          />
        );
      })}
    </>
  );
}

export default App;
