import Counter from "./components/Counter";
function App() {
  let studentList = [
    "Ajay",
    "Ajay",
    "Ajay",
    "Pallavi",
    "Archana",
    "Deepak",
    "Hritik",
  ];
  return (
    <>
      <ul>
        {studentList.map((student, index) => (
          <li key={index}>{student}</li>
        ))}
      </ul>
    </>
  );
}

export default App;
