import React from "react";
import { Link } from "react-router-dom";

function PageNotFound(props) {
  return (
    <div>
      This page is not avalable <Link to="/">CLICK For Home</Link>
    </div>
  );
}

export default PageNotFound;
