import { Field, Form, Formik } from "formik";
import React from "react";

function Home({ saveStudent }) {
  let initialValues = {
    name: "",
    class: "",
  };
  let onSubmit = (values) => {
    saveStudent({ ...values });
  };
  return (
    <>
      <div className="row flex justify-content-center">
        <Formik initialValues={initialValues} onSubmit={onSubmit}>
          <Form className="col-10 col-lg-4 col-md-6 col-sm-10 card p-4">
            <div className="mb-4">
              <label htmlFor="" class="form-label">
                Student Name
              </label>
              <Field
                type="text"
                class="form-control"
                name="name"
                autoComplete="off"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="" class="form-label">
                Class
              </label>
              <Field as="select" class="form-select" name="class">
                <option value="">--Section--</option>
                <option value="react">React</option>
                <option value="js">JS</option>
                <option value="node">Node</option>
                <option value="mongo_db">MongoDB</option>
              </Field>
            </div>
            <button type="submit" class="btn btn-success">
              Save Student
            </button>
          </Form>
        </Formik>
      </div>
    </>
  );
}

export default Home;
