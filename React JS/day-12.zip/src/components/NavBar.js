import React from "react";
import { Link } from "react-router-dom";

function NavBar() {
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <div className="navbar-nav">
            <Link to="/" className="nav-link">
              Home
            </Link>

            <Link to="/student-list" className="nav-link">
              Student List
            </Link>

            <Link to="/users" className="nav-link">
              User
            </Link>
          </div>
        </div>
      </nav>
    </>
  );
}
export default NavBar;
