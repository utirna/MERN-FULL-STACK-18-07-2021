import React from "react";

function OurProject() {
  return <div>Our Project Page</div>;
}

export default OurProject;
