import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

let base_url = "https://jsonplaceholder.typicode.com/";
function Users(props) {
  let navigate = useNavigate();

  let { userList, setUserList } = props;

  let getUserList = async () => {
    let url = base_url + "users";
    let result = await axios.get(url);
    setUserList(result.data);
  };

  let getIndex = (index) => {
    navigate("/users/profile/" + index);
  };

  useEffect(() => {
    getUserList();
  }, []);

  return (
    <div>
      <ul className="list">
        {userList.map((user, index) => (
          <li key={index} onClick={() => getIndex(index)}>
            {user.name}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Users;
