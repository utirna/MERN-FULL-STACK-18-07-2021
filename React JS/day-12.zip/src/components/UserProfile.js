import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function UserProfile(props) {
  let params = useParams();

  let [userProfileDetails, setUserProfileDetails] = useState({
    name: "-",
    username: "-",
    email: "-",
    website: "-",
  });

  useEffect(() => {
    setUserProfileDetails({ ...props.userList[Number(params.id)] });
  }, []);

  return (
    <section className="profile-section">
      <header>User profile</header>
      <article>
        <ul>
          <li className="text-success">
            Name: <strong>{userProfileDetails.name}</strong>
          </li>
          <li className="text-success">
            User Name: <strong>{userProfileDetails.username}</strong>
          </li>
          <li className="text-success">
            Email ID: <strong>{userProfileDetails.email}</strong>
          </li>
          <li className="text-success">
            Website: <strong>{userProfileDetails.website}</strong>
          </li>
        </ul>
      </article>
    </section>
  );
}

export default UserProfile;
