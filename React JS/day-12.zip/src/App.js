import React, { useState } from "react";
import Home from "./components/Home";
import NavBar from "./components/NavBar";
import About from "./components/About";
import Contact from "./components/Contact";
import OurProject from "./components/OurProject";
import { Route, Routes } from "react-router-dom";
import Users from "./components/Users";
import UserProfile from "./components/UserProfile";
import PageNotFound from "./components/PageNotFound";

function App() {
  let [students, setStudents] = useState([]);
  let [userList, setUserList] = useState([]);

  let saveStudent = (newStudent) => {
    let studentList = [...students];
    studentList.push(newStudent);
    setStudents(studentList);
  };

  return (
    <>
      <main className="container">
        <NavBar />
        <Routes>
          <Route path="/" element={<Home saveStudent={saveStudent} />} />
          <Route path="/student-list" element={<About students={students} />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/our-project" element={<OurProject />} />
          <Route
            path="/users"
            element={<Users userList={userList} setUserList={setUserList} />}
          />
          <Route
            path="/users/profile/:id"
            element={<UserProfile userList={userList} />}
          />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </main>
    </>
  );
}

export default App;
