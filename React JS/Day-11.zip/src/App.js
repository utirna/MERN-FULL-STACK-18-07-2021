import React, { useState } from "react";
import Home from "./components/Home";
import NavBar from "./components/NavBar";
import About from "./components/About";
import Contact from "./components/Contact";
import OurProject from "./components/OurProject";
import { Route, Routes } from "react-router-dom";
import Users from "./components/Users";

function App() {
  let [students, setStudents] = useState([]);

  let saveStudent = (newStudent) => {
    let studentList = [...students];
    studentList.push(newStudent);
    setStudents(studentList);
  };
  console.log(students);
  return (
    <>
      <NavBar />
      <Routes>
        <Route path="/" element={<Home saveStudent={saveStudent} />} />
        <Route path="/about" element={<About students={students} />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/our-project" element={<OurProject />} />
        <Route path="/users" element={<Users />} />
      </Routes>
    </>
  );
}

export default App;
