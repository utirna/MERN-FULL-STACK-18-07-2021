import React from "react";

function About({ students }) {
  return (
    <div>
      Student List
      <ul>
        {students.map((student) => (
          <li>{student.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default About;
