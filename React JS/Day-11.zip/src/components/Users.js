import React, { useEffect, useState } from "react";
import axios from "axios";
let base_url = "https://jsonplaceholder.typicode.com/";
function Users() {
  let [userList, setUserList] = useState([]);
  let [userProfileDetails, setUserProfileDetails] = useState({
    name: "-",
    username: "-",
    email: "-",
    website: "-",
  });

  let getUserList = async () => {
    let url = base_url + "users";
    let result = await axios.get(url);
    setUserList(result.data);
  };

  let getProfileDetails = (index) => {
    setUserProfileDetails({ ...userList[index] });
  };

  useEffect(() => {
    getUserList();
  }, []);

  return (
    <div>
      <ul className="list">
        {userList.map((user, index) => (
          <li key={index} onClick={() => getProfileDetails(index)}>
            {user.name}
          </li>
        ))}
      </ul>
      <section className="profile-section">
        <header>User profile</header>
        <article>
          <ul>
            <li>
              Name: <strong>{userProfileDetails.name}</strong>
            </li>
            <li>
              User Name: <strong>{userProfileDetails.username}</strong>
            </li>
            <li>
              Email ID: <strong>{userProfileDetails.email}</strong>
            </li>
            <li>
              Website: <strong>{userProfileDetails.website}</strong>
            </li>
          </ul>
        </article>
      </section>
    </div>
  );
}

export default Users;
