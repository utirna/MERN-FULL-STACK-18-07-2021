import React from "react";

function Contact() {
  return <div>Contact Page</div>;
}

export default Contact;
