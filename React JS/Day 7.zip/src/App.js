import React from "react";
import StudentForm from "./components/StudentForm";

function App() {
  return (
    <>
      <StudentForm />
    </>
  );
}

export default App;
