import React, { useEffect, useState } from "react";

function App() {
  let [count, setCount] = useState(1);
  let [count1, setCount1] = useState(1);

  let updateData = () => {
    setCount(count + 1);
  };

  let updateData1 = () => {
    setCount1(count1 + 1);
  };

  useEffect(() => {
    console.log("this is effect");
  }, [count, count1]);

  useEffect(() => {
    console.log("this is effect -1");
  }, [count1]);

  return (
    <>
      <h4>{count}</h4>
      <button onClick={updateData}>CLICK</button>
      <button onClick={updateData1}>CLICK 1</button>
    </>
  );
}

export default App;
