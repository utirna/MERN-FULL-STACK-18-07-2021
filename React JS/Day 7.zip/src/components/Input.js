import { React } from "react";
function Input({ value, updateInput, name, label }) {
  return (
    <>
      <div className="flex flex-dc form-group">
        <label htmlFor="">{label}</label>
        <input
          type="text"
          placeholder={"Enter " + label}
          className="form-control"
          value={value}
          onChange={updateInput}
          name={name}
        />
      </div>
    </>
  );
}

export default Input;
