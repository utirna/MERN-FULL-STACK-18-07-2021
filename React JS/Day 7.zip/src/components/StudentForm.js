import React, { useState } from "react";
import Input from "./Input";

function StudentForm() {
  let [students, setStudents] = useState([]);

  let [studentForm, setStudentForm] = useState({
    s_name: "",
    roll_no: "",
    mobile: "",
  });

  let updateInput = (event) => {
    let { value, name } = event.target;
    let _studForm = { ...studentForm };
    _studForm[name] = value;
    setStudentForm(_studForm);
  };

  let saveNewStudent = (event) => {
    event.preventDefault();

    let _students = [...students];
    _students.push({ ...studentForm });
    setStudents(_students);
  };

  return (
    <>
      <form
        onSubmit={saveNewStudent}
        className="flex flex-jcc flex-aic flex-dc form"
      >
        <Input
          value={studentForm.s_name}
          updateInput={updateInput}
          name="s_name"
          label="Student Name"
        />

        <Input
          value={studentForm.roll_no}
          updateInput={updateInput}
          name="roll_no"
          label="Student Roll No"
        />

        <Input
          value={studentForm.mobile}
          updateInput={updateInput}
          name="mobile"
          label="Student Mobile-1"
        />
        <button>Submit</button>
      </form>
      <ul>
        {students.map((student, index) => (
          <li key={index}>{student.s_name}</li>
        ))}
      </ul>
    </>
  );
}

export default StudentForm;
