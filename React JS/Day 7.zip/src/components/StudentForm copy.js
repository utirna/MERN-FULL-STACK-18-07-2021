import React, { useState } from "react";

function StudentForm() {
  let [students, setStudents] = useState([]);

  let [studentForm, setStudentForm] = useState({
    s_name: "",
    roll_no: "",
    mobile: "",
  });

  let updateInput = (event) => {
    let { value, name } = event.target;
    let _studForm = { ...studentForm };
    _studForm[name] = value;
    setStudentForm(_studForm);
  };

  let saveNewStudent = (event) => {
    event.preventDefault();

    let _students = [...students];
    _students.push({ ...studentForm });
    setStudents(_students);
  };

  console.log(students);
  return (
    <>
      <form
        onSubmit={saveNewStudent}
        className="flex flex-jcc flex-aic flex-dc form"
      >
        <div className="flex flex-dc form-group">
          <label htmlFor="">Student Name</label>
          <input
            type="text"
            placeholder="enter student name"
            className="form-control"
            value={studentForm.s_name}
            onChange={updateInput}
            name="s_name"
          />
        </div>

        <div className="flex flex-dc form-group">
          <label htmlFor="">Student Roll No</label>
          <input
            type="text"
            placeholder="enter student roll no"
            className="form-control"
            value={studentForm.roll_no}
            onChange={updateInput}
            name="roll_no"
          />
        </div>

        <div className="flex flex-dc form-group">
          <label htmlFor="">Student Mobile</label>
          <input
            type="text"
            placeholder="enter student mobile no"
            className="form-control"
            value={studentForm.mobile}
            onChange={updateInput}
            name="mobile"
          />
        </div>
        <button>Submit</button>
      </form>
      <ul>
        {students.map((student, index) => (
          <li key={index}>{student.s_name}</li>
        ))}
      </ul>
    </>
  );
}

export default StudentForm;
