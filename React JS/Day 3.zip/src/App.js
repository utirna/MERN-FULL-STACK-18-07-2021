import React from "react";
import Counter from "./components/Counter";
import CounterClass from "./components/CounterClass";

function App() {
  return (
    <main>
      <Counter />
      <CounterClass />
    </main>
  );
}

export default App;
