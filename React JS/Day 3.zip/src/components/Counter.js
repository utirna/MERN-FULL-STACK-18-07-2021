import React, { useState } from "react";

function Counter() {
  let [count, setCount] = useState(0);

  let printText = function () {
    setCount(++count);
  };

  return (
    <>
      <h1>{count}</h1>
      <button onClick={printText} className="btn btn-success">
        Inc Count
      </button>
    </>
  );
}

export default Counter;
